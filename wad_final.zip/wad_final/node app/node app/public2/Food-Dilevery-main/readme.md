Food delivery website with responsive front-end just using Html CSS and JS

<img src="https://github.com/ahmedrohailawan/Food-Delivery-project/blob/main/readme%20files/pg1.png" width="900">
<img src="https://github.com/ahmedrohailawan/Food-Delivery-project/blob/main/readme%20files/pg2.png" width="900">
<img src="https://github.com/ahmedrohailawan/Food-Delivery-project/blob/main/readme%20files/pg3.png" width="900">
<img src="https://github.com/ahmedrohailawan/Food-Delivery-project/blob/main/readme%20files/pg4.png" width="900">




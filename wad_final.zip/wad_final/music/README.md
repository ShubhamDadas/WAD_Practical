# Perform following tasks using nodejs, Expressjs and MongoDB. Following operation should be perform in Nodejs and Expressjs only. 

a. Create a Database called music.

b. Create a collection called songdetails

c. Insert array of 5 song documents in above Collection. 
  - Document have following field: 
    - Songname, Film, Music_director, singer

d. Display total count of documents and List all the documents in browser.

e. List specified Music Director songs.

f. List specified Music Director songs sung by specified Singer

g. Delete the song which you don’t like. 

h. Add new song which is your favorite.

i. List Songs sung by Specified Singer from specified film.

j. Update the document by adding Actor and Actress name.

k. Display the data in Browser in tabular format.